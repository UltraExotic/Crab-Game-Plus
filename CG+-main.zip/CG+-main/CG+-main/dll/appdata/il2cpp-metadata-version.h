// Generated C++ file by Il2CppInspector - http://www.djkaty.com - https://github.com/djkaty
// Target Unity version: 2020.2.4 - 2020.3.99

#define __IL2CPP_METADATA_VERSION 271
