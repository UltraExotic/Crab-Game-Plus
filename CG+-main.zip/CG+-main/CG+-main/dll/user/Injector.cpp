#include "pch-il2cpp.h"
#include "Injector.h"

uintptr_t Injector::m_AssemblyBase = 0;