#include "pch-il2cpp.h"

class SnowBrawl {
public:
	static float SpawnSnowballsTime;
	static bool CanSpawnSnowballs;
	static void IncrementSpawnSnowballsTime(float dt);
	static void SpawnSnowballs();
};