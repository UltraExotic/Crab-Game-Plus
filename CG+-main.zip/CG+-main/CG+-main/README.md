
# Crabiest Crab Game Mods

[![Crabiest Crab Game Mods](https://i.ibb.co/RgrcnJz/ccgm-long-transparent-cropped-center-small.png)](https://nodesource.com/products/nsolid)

## Everything You Need

With Crabiest Crab Game Mods, you'll have everything you need to create your own awesome 24/7 servers.

## Features

- Permanent bans
- Moderation teams
- Custom game modes
- Custom commands
- Discord integration
- Leaderboards
- Ban logs
- Player reporting system
- Live invite codes and server info
- Chat logs
- Moderation logs
- Player stats
- Run multiple servers on the same machine with our sandboxie support
- Headless mode support to greatly improve performance on machines without a graphics card
- Watchdog to keep your servers running even when they freeze or crash
- And more!

CCGM was developed by modifying Danilo's mod:</br>
[Crab Game Server Mod](https://github.com/Danilo1301/crab-game-server-mod)

More specifically, version 1.3.1.

CCGM also modified o7moon's mod:</br>
[Crab Game Map Mod](https://github.com/o7Moon/CrabGame.MapMod)

The injector is not mine either; credit to nefarius:</br>
[Nefarius Injector](https://github.com/nefarius/Injector)

## Disclaimer

I am a self-taught programmer who created this in my free time. There is a TON of room for updates and improvements. There is no guarantee that this software will work as intended. That said, please don't hesitate to send me your suggestions.

## Installation and Usage

I've put together a helpful YouTube series to guide you through everything!</br>
Once it's complete, I'll provide the link here.

## Community and Support

Join us on Discord!</br>
[https://dsc.gg/ccgm](https://dsc.gg/ccgm)
